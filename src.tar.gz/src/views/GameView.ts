class GameView extends ViewBase {
    
}