class MenuView extends ViewBase {
    public constructor(canvas: HTMLCanvasElement) {
        super(canvas);
    }

    protected HandleOnClick = (xPos: number, yPos: number) => {}
    protected RenderScreen() {}
}