interface Score {
    playerName: string;
    score: number;
}